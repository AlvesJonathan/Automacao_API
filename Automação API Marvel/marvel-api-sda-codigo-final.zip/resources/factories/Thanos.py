# from faker import Faker
# faker = Faker()

def factory_thanos():

	return {
		"name": "Thanos de Titã",
		"aliases": "Thanos",
		"age": 3000,
		"team": "Ordem Negra",
		"active": False
	}
