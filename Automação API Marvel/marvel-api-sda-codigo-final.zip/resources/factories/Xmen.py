


def factory_logan():

    return {
	    "name": "Logan",
	    "aliases": "Wolverine",
	    "age": 100,
	    "team": "X-men",
	    "active": True
    }

def factory_ciclope():

	return {
		"name": "Ciclope",
		"aliases": "Ciclope",
		"age": 25,
		"team": "X-men",
		"active": True
	}