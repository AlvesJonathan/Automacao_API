

def factory_star_lord():

    return {
		"name": "Peter Quill",
		"aliases": "Star Lord",
		"age": 30,
		"team": "Guardians of the Galaxy",
		"active": True
	}

def factory_groot():

    return {
		"name": "Groot",
		"aliases": "Groot",
		"age": 300,
		"team": "Guardians of the Galaxy",
		"active": True
	} 